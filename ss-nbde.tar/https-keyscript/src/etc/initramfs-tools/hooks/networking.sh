#!/bin/sh
PREREQ=""


prereqs()
{
   echo "$PREREQ"
}

case $1 in
prereqs)
   prereqs
   exit 0
   ;;
esac

. /usr/share/initramfs-tools/hook-functions

copy_exec /usr/lib/x86_64-linux-gnu/libnss_dns.so.2
copy_exec /usr/lib/x86_64-linux-gnu/libnss_files.so.2
copy_exec /usr/lib/x86_64-linux-gnu/libresolv.so.2
