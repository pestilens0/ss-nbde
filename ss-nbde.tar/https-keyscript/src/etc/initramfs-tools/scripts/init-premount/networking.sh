#!/bin/sh
#set -e
set -e

PREREQ=""

prereqs()
{
    echo "$PREREQ"
}

case $1 in
    prereqs)
        prereqs
        exit 0
        ;;
esac

. /scripts/functions

INTERFACE=""
IP_ADDRESS=""
NETMASK=""
GATEWAY=""
DNS1="10.255.255.1"
DNS2="10.255.255.2"

wait_for_udev 10

ip addr add $IP_ADDRESS/$NETMASK dev $INTERFACE
ip link set $INTERFACE up
ip route add default via $GATEWAY dev $INTERFACE

echo "nameserver $DNS1" > /etc/resolv.conf
echo "nameserver $DNS2" >> /etc/resolv.conf
